package com.sadeqa.jamal.newsquds

const val API_KEY = "3be0a6fe46724998bf34ad97fea331c9"
const val BASE_URL = "https://newsapi.org"
const val SEARCH_NEWS_TIME_DELAY = 500L
const val QUERY_PAGE_SIZE = 20
