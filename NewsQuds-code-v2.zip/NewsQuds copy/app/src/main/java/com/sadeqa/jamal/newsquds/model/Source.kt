package com.sadeqa.jamal.newsquds.model


data class Source(
    val id: Any,
    val name: String
)